// AppointmentTest.java
import org.junit.Test;
import static org.junit.Assert.;
import java.util.Date;

public class AppointmentTest {
    @Test
    public void testValidAppointment() {
        Date future = new Date(System.currentTimeMillis() + 86400000);
        Appointment a = new Appointment("1234567890", future, "desc");
        assertEquals("1234567890", a.getAppointmentId());
        assertEquals(future, a.getAppointmentDate());
        assertEquals("desc", a.getDescription());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidIdNull() { new Appointment(null, new Date(System.currentTimeMillis() + 86400000), "desc"); }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidIdLong() { new Appointment("12345678901", new Date(System.currentTimeMillis() + 86400000), "desc"); }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidDateNull() { new Appointment("1234567890", null, "desc"); }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidDatePast() { new Appointment("1234567890", new Date(System.currentTimeMillis() - 86400000), "desc"); }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidDescNull() { new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), null); }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidDescLong() { new Appointment("1234567890", new Date(System.currentTimeMillis() + 86400000), "123456789012345678901234567890123456789012345678901"); }
}