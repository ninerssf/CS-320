// AppointmentServiceTest.java
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.Date;

public class AppointmentServiceTest {
    @Test
    public void testAddAndDelete() {
        AppointmentService s = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 86400000);
        Appointment a = new Appointment("1234567890", future, "desc");
        s.addAppointment(a);
        assertNotNull(s.getAppointment("1234567890"));
        s.deleteAppointment("1234567890");
        assertNull(s.getAppointment("1234567890"));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testAddDuplicate() {
        AppointmentService s = new AppointmentService();
        Date future = new Date(System.currentTimeMillis() + 86400000);
        Appointment a1 = new Appointment("1234567890", future, "desc");
        Appointment a2 = new Appointment("1234567890", future, "desc2");
        s.addAppointment(a1);
        s.addAppointment(a2);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDeleteMissing() {
        new AppointmentService().deleteAppointment("missing");
    }
}