import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions;

class ContactTest {

    @Test
    void testValidContactCreation() {
        Contact contact = new Contact("ID1234567", "Chris", "Ouk", "7149991234", "123 Lake St, Lake Charles");
        assertEquals("ID1234567", contact.getContactId());
        assertEquals("Chris",     contact.getFirstName());
        assertEquals("Ouk",       contact.getLastName());
        assertEquals("7149991234",contact.getPhone());
        assertEquals("123 Lake St, Lake Charles", contact.getAddress());
    }

    @Test
    void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("12345678901", "Chris", "Ouk", "7149991234", "123 Lake St"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact(null, "Chris", "Ouk", "7149991234", "123 Lake St"));
    }

    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID1", "Chris", "Ouk", "7149991234", "123 Lake St"));
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID1", null, "Ouk", "7149991234", "123 Lake St"));
    }

    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID1", "Chris", "Ouk", "714999123", "123 Lake St"));     // too short
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID1", "Chris", "Ouk", "7149991234A", "123 Lake St"));    // not digits
        assertThrows(IllegalArgumentException.class, () ->
                new Contact("ID1", "Chris", "Ouk", null, "123 Lake St"));
    }

    @Test
    void testUpdateFields() {
        Contact c = new Contact("ID999", "Test", "User", "1234567890", "Short addr");
        c.setFirstName("NewFirst");
        c.setLastName("NewLast");
        c.setPhone("7149991234");
        c.setAddress("Longer address up to 30 chars ok");

        assertEquals("NewFirst", c.getFirstName());
        assertEquals("NewLast",  c.getLastName());
        assertEquals("9876543210", c.getPhone());
        assertEquals("Longer address up to 30 chars ok", c.getAddress());
    }
}