import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact c = new Contact("1212", "Chris", "Ouk", "7149991234", "123 Lake St");
        assertTrue(service.addContact(c));
        assertEquals(1, service.getContactCount());
    }

    @Test
    void testCannotAddDuplicate() {
        Contact c = new Contact("2001", "Ryan", "Bruce", "1112223333", "1111 Elm St");
        service.addContact(c);
        assertFalse(service.addContact(c));   // Same one
    }

    @Test
    void testDeleteContact() {
        Contact c = new Contact("3001", "Sara", "Robert", "7145551234", "Sunset Ln");
        service.addContact(c);
        assertTrue(service.deleteContact("3001"));
        assertEquals(0, service.getContactCount());
    }

    @Test
    void testUpdateContact() {
        Contact c = new Contact("2323", "Mike", "Homer", "9094553412", "9856 Maple Ln");
        service.addContact(c);

        service.updateFirstName("2323", "Joe");
        service.updatePhone("2323", "9095661717");

        Contact updated = service.getContact("2323");
        assertEquals("Joe", updated.getFirstName());
        assertEquals("9095661717", updated.getPhone());
    }
}