package task;

public class Task {
    private final String taskId;      // 10 characters
    private String name;              // <= 20 chars, not null
    private String description;       // <= 50 chars, not null

    // Constructor
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException // No greater than 10 characters
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException // Name cannot exceed 20 characters
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException // Description is require and cannot exceed 50 characters
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }

    
    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException // Name cannot be null
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException // Description cannot be null and exceed 50 characters
        }
        this.description = description;
    }
}