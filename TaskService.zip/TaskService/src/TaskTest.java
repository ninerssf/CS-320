public class TaskTest 

package task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class TaskTest {

    @Test
    void testCreateValidTask() {
        Task t = new Task("12345", "My Task", "This is a test task");
        assertEquals("12345", t.getTaskId());
        assertEquals("My Task", t.getName());
        assertEquals("This is a test task", t.getDescription());
    }

    @Test
    void testInvalidTaskId() {
        assertThrows(IllegalArgumentException.class, () -> 
            new Task("0123456789", "Name", "Desc"));
    }

    @Test
    void testUpdateName() {
        Task t = new Task("1", "Old", "Desc");
        t.setName("New Name");
        assertEquals("New Name", t.getName());
    }
}
