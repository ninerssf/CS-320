public class TaskService 

package task;

import java.util.ArrayList;
import java.util.List;

public class TaskService {
    private List<Task> tasks = new ArrayList<>();

    public void addTask(Task task) {
        if (task == null) throw new IllegalArgumentException;

        for (Task t : tasks) {
            if (t.getTaskId().equals(task.getTaskId())) {
                throw new IllegalArgumentException;
            }
        }
        tasks.add(task);
    }

    public void deleteTask(String taskId) {
        if (taskId == null) throw new IllegalArgumentException;
        
        tasks.removeIf(task -> task.getTaskId().equals(taskId));
    }

    public void updateTask(String taskId, String name, String description) {
        if (taskId == null) throw new IllegalArgumentException;

        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                if (name != null) task.setName(name);
                if (description != null) task.setDescription(description);
                return;
            }
        }
        throw new IllegalArgumentException;
    }

    // Help for testing
    public Task getTask(String taskId) {
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                return task;
            }
        }
        return null;
    }
}
