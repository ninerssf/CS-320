public class TaskServiceTest 

package task;

import static org.junit.jupiter.api.Assertions.;
import org.junit.jupiter.api.Test;

class TaskServiceTest {

    @Test
    void testAddAndGetTask() {
        TaskService service = new TaskService();
        Task task = new Task("JENNER123", "Homework", "assignment");
        
        service.addTask(task);
        assertNotNull(service.getTask("JENNER123"));
    }

    @Test
    void testCannotAddDuplicateId() {
        TaskService service = new TaskService();
        Task t1 = new Task("JENNER123", "Task1", "Desc1");
        Task t2 = new Task("JENNER123", "Task2", "Desc2");

        service.addTask(t1);
        assertThrows(IllegalArgumentException.class, () -> service.addTask(t2));
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        Task task = new Task("999", "Delete Me", "Test");
        service.addTask(task);
        
        service.deleteTask("999");
        assertNull(service.getTask("999"));
    }

    @Test
    void testUpdateTask() {
        TaskService service = new TaskService();
        Task task = new Task("555", "Old Name", "Old Desc");
        service.addTask(task);

        service.updateTask("555", "New Name", "New Desc");

        Task updated = service.getTask("555");
        assertEquals("New Name", updated.getName());
        assertEquals("New Desc", updated.getDescription());
    }
}
